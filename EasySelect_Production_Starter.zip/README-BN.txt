Easy Select Production Starter
এটি starter/PWA prototype। Admin login এখন demo-only; production-এ backend authentication, database, secure sessions ও role-based access control লাগবে।
Google Search-এর জন্য domain/hosting, Search Console verification ও sitemap submission লাগবে।
Android app-এর মতো install করার জন্য HTTPS hosting-এর পরে Chrome থেকে Add to Home Screen/Install করা যাবে।
