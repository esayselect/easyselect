// Supabase public browser configuration.
// Never put a service_role/secret key here.
window.SUPABASE_URL = "https://kiiriwnqcmhelsaddxod.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_PUBLISHABLE_KEY_HERE";
