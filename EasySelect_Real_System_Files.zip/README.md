Easy Select real-system starter

1. Supabase SQL Editor-এ supabase.sql পুরোটা Run করুন।
2. Supabase Authentication > Users থেকে নিজের account তৈরি করুন।
3. আপনার user UUID নিয়ে SQL Editor-এ:
   update public.profiles set role='admin' where id='YOUR_UUID';
4. config.js-এ SUPABASE_PUBLISHABLE_KEY বসান। service_role/secret key কখনো নয়।
5. GitHub repository root-এ index.html, styles.css, app.js, config.js, supabase.sql upload করুন।
6. GitHub Pages URL Supabase Authentication > URL Configuration > Site URL হিসেবে দিন:
   https://esayselect.github.io/easyselect/
7. Redirect URL-এ একই URL যোগ করুন।

Note: এটি production foundation. bKash automatic payment verification-এর জন্য authorized merchant/API integration আলাদা করে করতে হবে.
